/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Operaciones {
     // Lógica: suma dos números
    public int sumar(int a, int b) {
        return a + b;
    }

    // Interacción
    // Llama a otro método propio de la clase
    public int sumaDoble(int a, int b) {
        int suma = sumar(a, b);      // interacción interna
        return suma * 2;
    }
}

