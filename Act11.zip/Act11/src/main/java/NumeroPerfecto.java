/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class NumeroPerfecto {

    // ¿Es perfecto el número dado?
    public boolean isPerfect(int number) {
        if (number <= 1) return false;
        int sum = 1;
        for (int i = 2; i <= number / 2; i++) {
            if (number % i == 0) sum += i;
        }
        return sum == number;
    }

    // Calcular la suma factorial del número
    public String factorSum(int number) {
        if (number < 0) return "0";
        long factorial = 1;
        long suma = 0;
        for (int i = 1; i <= number; i++) {
            factorial *= i;
            suma += factorial;
        }
        return Long.toString(suma);
    }

    // Encuentra números perfectos dado el límite
    public String findPerfectNumbers(int limit) {
        StringBuilder sb = new StringBuilder();
        for (int i = 2; i <= limit; i++) {
            if (isPerfect(i)) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(i);
            }
        }
        return sb.toString();
    }
}
