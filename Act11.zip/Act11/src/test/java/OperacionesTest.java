/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class OperacionesTest {
    
    Operaciones op = new Operaciones();

    // LÓGICA
    @Test
    public void testSumar() {
        assertEquals(5, op.sumar(2, 3));
    }

    // INTERACCIÓN
    @Test
    public void testSumaDoble() {
        assertEquals(10, op.sumaDoble(2, 3)); // (2+3)*2 = 10
    }

    // REGRESIÓN
    @Test
    public void testSumarRegresion() {
        assertEquals(0, op.sumar(-1, 1));
    }
}
