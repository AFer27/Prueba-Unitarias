/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class NumeroPerfectoTest {
    
    NumeroPerfecto np = new NumeroPerfecto();

    @Test
    public void testIsPerfect() {
        assertTrue(np.isPerfect(6));      // 6 es número perfecto
        assertTrue(np.isPerfect(28));     // 28 es número perfecto
        assertFalse(np.isPerfect(10));    // 10 no es perfecto
    }

    @Test
    public void testFactorSum() {
        assertEquals("9", np.factorSum(3)); // 1+2+6=9
        assertEquals("153", np.factorSum(5)); // 1+2+6+24+120=153
        assertEquals("0", np.factorSum(-1));  // negativo da "0"
    }

    @Test
    public void testFindPerfectNumbers() {
        assertEquals("6, 28", np.findPerfectNumbers(30));
        assertEquals("6", np.findPerfectNumbers(7));
        assertEquals("", np.findPerfectNumbers(5));
    }
}
