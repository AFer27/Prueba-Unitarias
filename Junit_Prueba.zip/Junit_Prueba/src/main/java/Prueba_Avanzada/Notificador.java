package Prueba_Avanzada;

public interface Notificador {
	void notificar(String mensaje);
}
