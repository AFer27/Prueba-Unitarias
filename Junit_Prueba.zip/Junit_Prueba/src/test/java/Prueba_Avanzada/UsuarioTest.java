package Prueba_Avanzada;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

class UsuarioTest {

	@Test
    public void testNotificacionLlamada() {
        // Se crea un mock
        Notificador mockNotif = mock(Notificador.class);

        // Se usa el mock
        Usuario usuario = new Usuario(mockNotif);
        usuario.enviarMensaje("Hola!");

        // Se verifica que se llamó a notificar con el mensaje correcto
        verify(mockNotif).notificar("Hola!");
    }
}
